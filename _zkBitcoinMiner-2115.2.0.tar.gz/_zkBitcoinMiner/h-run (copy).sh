#!/bin/bash

# Prompt user to enter the private key
read -sp "Enter your private key: " private_key
echo

# Check if private key is not empty
if [[ -z "$private_key" ]]; then
  echo "Private key cannot be empty."
  exit 1
fi

# Backup existing .bashrc
cp ~/.bashrc ~/.bashrc.bak

# Add the private key to .bashrc
echo "export PRIVATE_KEY=\"$private_key\"" >> ~/.bashrc

# Inform the user
echo "Private key has been added to .bashrc and a backup of the original .bashrc has been created as .bashrc.bak."

# Source the .bashrc file to apply changes
source ~/.bashrc

