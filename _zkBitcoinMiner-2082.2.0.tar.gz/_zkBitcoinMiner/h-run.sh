#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

# Source the wallet.conf file
. /hive-config/wallet.conf

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

function version_gt() { test "$(printf '%s\n' "$@" | sort -V | head -n 1)" != "$1"; }

function install_deps() {
  . install-deps.sh

  # below is the temp fix for the following issue as of version 0.5-74, not required from 0.5-75 onwards.
  # /usr/lib/x86_64-linux-gnu/libcurl.so.4: version `CURL_OPENSSL_4' not found (required by curl)
  #if [[ $(lsb_release -sr) == "18.04" ]]; then
  #  apt-get install libtool m4 automake -y
  #  git clone https://github.com/curl/curl.git
  #  cd curl
  #  ./buildconf
  #  ./configure --disable-shared
  #  make
  #  make install
  #  cd ..
  #  rm -r -f curl
  #fi
}

command -v dotnet >/dev/null 2>&1 || {
  echo "dotnet not found, running install_deps..."
  install_deps
}

dotnetVersion=$(dotnet --info | grep "Version")
dotnetVersion=${dotnetVersion#*: }

if version_gt "2.2.0" $dotnetVersion; then
  echo "Found older version of dotnet, running install_deps..."
  install_deps
fi

depsFound=false
dotnetRuntimeVersion=$(dotnet --list-runtimes)

if [[ -z $dotnetRuntimeVersion ]]; then
 echo "dotnet runtime not found, running install_deps..."
 install_deps

else
 while read line || [ -n "$line" ]; do
  line=${line#*App }
  line=${line% [*}

  if version_gt $line "2.2.0"; then
   depsFound=true
  fi
 done < <(printf %s "$dotnetRuntimeVersion")

 if ! $depsFound; then
  echo "Found older version of dotnet runtime, running install_deps..."
  install_deps
 fi
fi


# Path to your JSON configuration file
CONFIG_FILE="_zkBitcoinMiner.conf"

# Check if the configuration file exists
if [[ ! -f $CONFIG_FILE ]]; then
    echo -e "Configuration file $CONFIG_FILE not found"
    exit 1
fi

# Function to update JSON configuration file
update_json() {
    local json_file=$1
    local key=$2
    local value=$3

    # Update the JSON file with the new key-value pair
    if grep -q "\"$key\":" "$json_file"; then
        sed -i "s/\"$key\":\s*\"[^\"]*\"/\"$key\": \"$value\"/" "$json_file"
    else
        sed -i "s/}/, \"$key\": \"$value\" }/" "$json_file"
    fi
}

# Function to parse JSON and generate command-line parameters
parse_json() {
    local json_file=$1
    local params=""

    # Read the JSON file line by line
    while IFS= read -r line; do
        # Extract key and value from the line
        key=$(echo "$line" | grep -o '"[^"]*"' | head -n 1 | sed 's/"//g')
        value=$(echo "$line" | grep -o '"[^"]*"' | tail -n 1 | sed 's/"//g')

        # Check for "minerAddress" and replace the value with $WALLET
        if [ "$key" == "minerAddress" ]; then
            params+="address=$CUSTOM_TEMPLATE "
            update_json $CONFIG_FILE "minerAddress" "$CUSTOM_TEMPLATE"
        elif [ "$key" == "primaryPool" ]; then
            update_json $CONFIG_FILE "pool" "$CUSTOM_URL"
            params+="pool=$CUSTOM_URL "
        elif [ "$key" == "privateKey" ]; then
            update_json $CONFIG_FILE "privateKey" "$value"
            params+="$key=$value "
	else
            params+="$key=$value "
        fi
    done < <(grep -Eo '"[^"]+":\s*"[^"]*"' "$json_file")

    echo "$params"
}


# Parse the JSON configuration file
PARAMS=$(parse_json $CONFIG_FILE)

# Print the parameters being used (for debugging purposes)
echo "Parameters: $PARAMS"



# Run the miner with the generated parameters and log the output
dotnet ./_zkBitcoinMiner.dll $PARAMS 2>&1 | tee $CUSTOM_LOG_BASENAME.log
