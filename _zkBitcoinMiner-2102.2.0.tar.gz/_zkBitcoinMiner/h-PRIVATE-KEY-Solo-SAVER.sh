#!/bin/bash

# Prompt user to enter the private key
read -sp "Enter your private key: " private_key
echo

# Check if private key is not empty
if [[ -z "$private_key" ]]; then
  echo "Private key cannot be empty."
  exit 1
fi

# Backup existing .bashrc
cp ~/.bashrc ~/.bashrc.bak

# Check if PRIVATE_KEY is already set in .bashrc and update it, otherwise add it
if grep -q "export PRIVATE_KEY=" ~/.bashrc; then
  # Update existing entry
  sed -i "s/export PRIVATE_KEY=.*/export PRIVATE_KEY=\"$private_key\"/" ~/.bashrc
else
  # Add new entry
  echo "export PRIVATE_KEY=\"$private_key\"" >> ~/.bashrc
fi

# Inform the user
echo "Private key has been added to .bashrc and a backup of the original .bashrc has been created as .bashrc.bak."

# Source the .bashrc file to apply changes
source ~/.bashrc

