#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

# Function to check if PRIVATE_KEY is set in the private_key.conf file
# Function to check if PRIVATE_KEY is set in the /etc/private_key.conf file
check_private_key() {
  if [[ ! -f /etc/private_key.conf ]]; then
    echo "/etc/private_key.conf does not exist."
    return 1
  fi

  PRIVATE_KEY=$(< /etc/private_key.conf)
  if [[ -n "$PRIVATE_KEY" ]]; then
    echo "Private key is set in /etc/private_key.conf."
    return 0
  else
    echo "Private key is not set in /etc/private_key.conf. Add your private key to the file."
    return 1
  fi
}


# Source the wallet.conf file
. /hive-config/wallet.conf

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

function version_gt() { test "$(printf '%s\n' "$@" | sort -V | head -n 1)" != "$1"; }

function install_deps() {
  . install-deps.sh
}

command -v dotnet >/dev/null 2>&1 || {
  echo "dotnet not found, running install_deps..."
  install_deps
}

dotnetVersion=$(dotnet --info | grep "Version")
dotnetVersion=${dotnetVersion#*: }

if version_gt "2.2.0" $dotnetVersion; then
  echo "Found older version of dotnet, running install_deps..."
  install_deps
fi

depsFound=false
dotnetRuntimeVersion=$(dotnet --list-runtimes)

if [[ -z $dotnetRuntimeVersion ]]; then
 echo "dotnet runtime not found, running install_deps..."
 install_deps

else
 while read line || [ -n "$line" ]; do
  line=${line#*App }
  line=${line% [*}

  if version_gt $line "2.2.0"; then
   depsFound=true
  fi
 done < <(printf %s "$dotnetRuntimeVersion")

 if ! $depsFound; then
  echo "Found older version of dotnet runtime, running install_deps..."
  install_deps
 fi
fi

# Path to your JSON configuration file
CONFIG_FILE="_zkBitcoinMiner.conf"

# Check if the configuration file exists
if [[ ! -f $CONFIG_FILE ]]; then
    echo -e "Configuration file $CONFIG_FILE not found"
    exit 1
fi

# Function to prompt the user to enter a private key
prompt_private_key() {
    while true; do
        read -sp "Enter your private key: " private_key
        echo

        if [[ -n "$private_key" ]]; then
            padded_key=$(echo "$private_key" | awk '{printf "%064s", substr($0, 3)}' | sed 's/ /0/g')
            private_key2="0x$padded_key"
            echo "Private Key saved as: $private_key2"

            private_key_file="/etc/private_key.conf"
            backup_file="${private_key_file}.bak"

            if [[ -f $private_key_file ]]; then
                if [[ -f $backup_file ]]; then
                    echo "$private_key2" >> $backup_file
                else
                    cp $private_key_file $backup_file
                    echo "$private_key2" >> $backup_file
                fi
                echo "A backup of the existing private_key.conf has been created or updated as $backup_file."
            fi

            echo "$private_key2" > $private_key_file
            echo "Private key has been added to $private_key2 and appended to $backup_file."
            break
        else
            echo "Private key cannot be empty."
        fi
    done
}

# Function to update JSON configuration file
update_json() {
    local json_file=$1
    local key=$2
    local value=$3

    # Update the JSON file with the new key-value pair
    if grep -q "\"$key\":" "$json_file"; then
        sed -i "s/\"$key\":\s*\"[^\"]*\"/\"$key\": \"$value\"/" "$json_file"
    else
        sed -i "s/}/, \"$key\": \"$value\" }/" "$json_file"
    fi
}

# Function to parse JSON and generate command-line parameters
parse_json() {
    local json_file=$1
    local params=""

    # Read the JSON file line by line
    while IFS= read -r line; do
        # Extract key and value from the line
        key=$(echo "$line" | grep -o '"[^"]*"' | head -n 1 | sed 's/"//g')
        value=$(echo "$line" | grep -o '"[^"]*"' | tail -n 1 | sed 's/"//g')

        # Check for "minerAddress" and replace the value with $WALLET
        if [ "$key" == "minerAddress" ]; then
            params+="address=$CUSTOM_TEMPLATE "
            update_json $CONFIG_FILE "minerAddress" "$CUSTOM_TEMPLATE"
        elif [ "$key" == "primaryPool" ]; then
            update_json $CONFIG_FILE "pool" "$CUSTOM_URL"
            params+="pool=$CUSTOM_URL "
        elif [ "$key" == "privateKey" ]; then

            lower_custom_user_config=$(echo "$CUSTOM_USER_CONFIG" | tr '[:upper:]' '[:lower:]')
            if [[ $lower_custom_user_config == *"-solo"* ]]; then
              params+="$key=$value "
              echo "set private key in Pool mode"
            else
              echo "Not setting private key because in Pool mode"
            fi
       else
            params+="$key=$value "
        fi
    done < <(grep -Eo '"[^"]+":\s*"[^"]*"' "$json_file")

    echo "$params"
}
#WE WANT THE SCRIPT TO GOHERE1
# Check and use the private key
# Main script logic
lower_custom_user_config=$(echo "$CUSTOM_USER_CONFIG" | tr '[:upper:]' '[:lower:]')
if check_private_key && [[ $lower_custom_user_config == *"-solo"* ]]; then
    echo -e "${RED}PRIVATEKEY is Set and program will run in SOLO mode thanks to -solo as the Extra config arguments in the flight sheet, to change private key run h-PRIVATE-KEY-Solo-SAVER.sh in /hive/miners/custom/_zkBitcoinMiner/ directory${NOCOLOR}"
    echo -e "${GREEN}PRIVATEKEY is Set and program will run in SOLO mode thanks to -solo as the Extra config arguments in the flight sheet${NOCOLOR}"
    input_key=$PRIVATE_KEY
    echo "INPUT KEY: $input_key"

    if [[ -z "$input_key" ]]; then
        echo "Private key is empty. Asking user to input there privateKey to continue."
        prompt_private_key
	check_private_key
        input_key=$PRIVATE_KEY
    fi

    padded_key=$(echo "$input_key" | awk '{printf "%064s", substr($0, 3)}' | sed 's/ /0/g')
    echo "PADDED KEY: $padded_key"

    private_key="0x$padded_key"
    masked_key=$(echo "$private_key" | sed -r 's/(.{58})(.{6})/\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\2/')
    echo "Using private key: $masked_key"
    update_json $CONFIG_FILE "privateKey" "$private_key"
elif [[ $lower_custom_user_config == *"-solo"* ]]; then
    echo -e "${RED}PRIVATEKEY is NOT SET and MUST INPUT PRIVATE KEY to continue, to change private key run h-PRIVATE-KEY-Solo-SAVER.sh in /hive/miners/custom/_zkBitcoinMiner/ directory ${NOCOLOR}"
    echo "Please set the private key first by running h-PRIVATE-KEY-Solo-SAVER.sh. Also must use -solo as the Extra config arguments in flight sheet"
    prompt_private_key
    check_private_key
    input_key=$PRIVATE_KEY

    padded_key=$(echo "$input_key" | awk '{printf "%064s", substr($0, 3)}' | sed 's/ /0/g')
    echo "PADDED KEY: $padded_key"

    private_key="0x$padded_key"
    masked_key=$(echo "$private_key" | sed -r 's/(.{58})(.{6})/\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\2/')
    echo "Using private key: $masked_key"
    echo -e "${GREEN}PRIVATEKEY is Set and program will run in SOLO mode thanks to -solo as the extra command in the flight sheet, to change private key run h-PRIVATE-KEY-Solo-SAVER.sh in /hive/miners/custom/_zkBitcoinMiner/ directory ${NOCOLOR}"
    #echo "Using private key: $private_key"
    update_json $CONFIG_FILE "privateKey" "$private_key"
else
  echo -e "${GREEN}Running in Pool mode, to switch to Solo mode add -solo as the Extra config arguments in the flight sheet${NOCOLOR}"
   
fi


# Parse the JSON configuration file
PARAMS=$(parse_json $CONFIG_FILE)

# Print the parameters being used (for debugging purposes)
echo "Parameters: $(echo $PARAMS | sed 's/privateKey=[^ ]*//g')"

# Run the miner with the generated parameters and log the output
dotnet ./_zkBitcoinMiner.dll $PARAMS 2>&1 | tee $CUSTOM_LOG_BASENAME.log

