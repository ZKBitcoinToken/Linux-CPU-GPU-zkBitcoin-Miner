#!/bin/bash

# Prompt user to enter the private key
read -sp "Enter your private key: " private_key
echo

# Check if private key is not empty
if [[ -z "$private_key" ]]; then
  echo "Private key cannot be empty."
  exit 1
fi

# Define the file to store the private key
private_key_file="private_key.conf"

# Backup existing private_key.conf if it exists
if [[ -f $private_key_file ]]; then
  cp $private_key_file "${private_key_file}.bak"
  echo "A backup of the existing private_key.conf has been created as ${private_key_file}.bak."
fi

# Write the private key to the file
echo "$private_key" > $private_key_file


# Inform the user
echo "Private key has been added to $private_key_file."
