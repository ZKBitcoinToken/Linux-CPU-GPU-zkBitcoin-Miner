from eth_account import Account

# Example private key (not secure)
input_key = "0x123123123"

# Pad the key with zeroes to make it 32 bytes (64 hexadecimal characters)
padded_key = input_key[2:].rjust(64, '0')

# Create the full private key
private_key = "0x" + padded_key

# Create an account from the private key
account = Account.from_key(private_key)

# Print the public address
print(f"Private Key: {private_key}")
print(f"Public Address: {account.address}")

